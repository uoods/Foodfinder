package edu.msudenver.foodfinder

import java.util.*

data class Location(
    var id: Int,
    var name: String,
    var address: String
    )