package edu.msudenver.foodfinder;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PlacesResponseModel {

//    @SerializedName("result")
//    @Expose
//    private List<GooglePlaceModel> googlePlaceModelList;


}
