package edu.msudenver.foodfinder

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class GoogleResponseModel {
//    @SerializedName("result")
//    @Expose

//    private List<GooglePlace>




}
